# Shell Jenkins scripts

Scripts for Jenkins written in shell.
