# Groovy Jenkins scripts

Scripts for Jenkins written in Groovy.
