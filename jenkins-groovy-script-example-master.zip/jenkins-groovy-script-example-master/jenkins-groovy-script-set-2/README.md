# Jenkins Script Console scripts

This repository contains [Jenkins Script Console][sc] scripts which are useful
for myself (Sam Gleske).

Other helpful script console script repositories:

- [CloudBees jenkins-scripts][cb].
- [JenkinsCI jenkins-scripts][js].
- [jenkins-bootstrap-shared contains script console scripts in `scripts/`][jbs]
  which is another project I created.
- [sandscape contains script console scripts][ss] which is another project I
  created.

[cb]: https://github.com/cloudbees/jenkins-scripts
[jbs]: https://github.com/samrocketman/jenkins-bootstrap-shared
[js]: https://github.com/jenkinsci/jenkins-scripts
[sc]: https://wiki.jenkins-ci.org/display/JENKINS/Jenkins+Script+Console
[ss]: https://github.com/sandscape/sandscape
